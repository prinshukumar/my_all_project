# Decision-Tree-for-Classification-Model-in-ML
In this ML model you have to predicts where the customer will purchase the item or not , and this is online web-page project which run on streamlite 
