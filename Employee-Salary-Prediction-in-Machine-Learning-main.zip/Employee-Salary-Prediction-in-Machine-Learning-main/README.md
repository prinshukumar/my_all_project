# Employee-Salary-Prediction-in-Machine-Learning
prediction the salary of the employee  on the given input , ML module gives us the amount of salary he deserved on the base of expriance year
