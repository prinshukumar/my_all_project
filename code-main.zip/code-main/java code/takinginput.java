import java.util.Scanner;

public class takinginput 
{
  
  /** 
   * @param args
   */
  public static void main(String[] args) 
  {
    //Scanner sc = new Scanner(System.in);
    Scanner sc =new Scanner(System.in);
    System.out.println("enter the nim");
    int a = sc.nextInt();
    System.out.println("enter the nim");
    int b = sc.nextInt();
    int sum=a+b;

    System.out.println(sum);
   

    

  }

  
}