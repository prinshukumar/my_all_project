public class time_hours {
    
    /** 
     * @param args
     */
    public static void main(String[] args) {
        
        System.out.println("print millli seconds");
        System.out.println(System.currentTimeMillis());
        System.out.println("print second seconds");
        System.out.println(System.currentTimeMillis()/1000);
        System.out.println("print mins seconds");
        System.out.println(System.currentTimeMillis()/1000/3600);
        System.out.println("print days seconds");
        System.out.println(System.currentTimeMillis());

    }
    
}
