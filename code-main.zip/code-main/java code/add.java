public class add
{
    
    /** 
     * @param args
     */
    public static void main(String[] args) 
    {
        int a=10, b=5, c ;
        c=a-b;
        System.out.println("additions \n a");
        System.out.println("additions\n"+c);
        
    }





}