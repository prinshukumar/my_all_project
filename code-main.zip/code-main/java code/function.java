public class function
{
    
    /** 
     * @param x
     * @param y
     * @return int
     */
    static int logice (int x,  int y)
    {
        int z;
        z=(x+y);
        return (z);

    }
    
    /** 
     * @param args
     */
    public static void main(String[] args) {
        int x ;
        int a=10;
        int b=20;
        x=logice(a,b);
        System.out.println(x);






    }












}