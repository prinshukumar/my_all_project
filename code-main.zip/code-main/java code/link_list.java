import java.util.*;
public class link_list 
{
    
    /** 
     * @param args
     */
    public static void main(String[] args) {
        LinkedList<Integer> l1 = new LinkedList<>();
        l1.add(4);
        System.out.println(l1);
        System.out.println(l1.get(0));
    }
    
}
