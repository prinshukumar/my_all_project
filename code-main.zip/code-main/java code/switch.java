import java.util.Scanner;
public class switch 
{
    public static void main(String[] args)
    {
        Scanner sc =new Scanner(System.in);
        System.out.println("enter the number");
        int a = sc.nextInt();
        switch (a)
        {
            case 56:
            System.out.println("you are expriance");
            break;
            case 46:
            System.out.println("you are sami expreance");
            break;
            case 26:
            System.out.println("find the job");
            break;
            default:
            System.out.println("enjiy the life");
        }


        
    }
    
}
