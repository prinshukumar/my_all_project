import java.util.*;
public class hash_set 
{
    
    /** 
     * @param args
     */
    public static void main(String[] args) {
        
        HashSet<Integer> h1 =new HashSet<Integer>();
        h1.add(5);
        h1.add(1);
        h1.add(6);
        h1.add(7);
        h1.add(6);
        System.out.println(h1);
        // for (int i = 0; i < 1;i++)
        // {
        // System.out.println(h1.get(i));
        // }
        

    }
    
}
