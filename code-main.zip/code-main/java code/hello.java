public class hello
{
    
    /** 
     * @param args
     */
    public static void main(String[] args) 
    {
    System.out.println("hi");       //ln make a new line
    System.out.print("hi");
        
    }





}