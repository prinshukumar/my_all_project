public class array {
    
    /** 
     * @param args
     */
    public static void main(String[] args) 
    {
        //int a[] = new int [10];
        //int a[ ]={5,6,5,4,3,2,1};
       // int a[];
        int a[]= new int [10];
       /* a = new int [6,5,4,3,2,1,4];
        a = new int [6];
        int i;
        for ( i = 0; i < 5; i++) 
        {
            System.out.println(a[i]);
            
        }                    */
        System.out.println(a[9]);
        
    }
}
