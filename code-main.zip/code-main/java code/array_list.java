//import java.util.ArrayList;
import java.util.*;
public class array_list 
{
    
    /** 
     * @param args
     */
    public static void main(String[] args) 
    {
    
        ArrayList<Integer> a1= new ArrayList<>();
        
//ArrayList<Integer> a2= new ArrayList<>(initial);
    a1.add(5+5);
    // a2(12);
    // a1.addAll(3);
    a1.clear();
    
    
    System.out.println(a1.get(0));
    System.out.println(a1);
            
    

}

    
}
