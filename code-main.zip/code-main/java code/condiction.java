import java.util.Scanner;
public class condiction 
{
    
    /** 
     * @param args
     */
    public static void main(String[] args)
    {
        Scanner sc =new Scanner(System.in);
        int a=sc.nextInt();
        boolean cond =(a>0);
        if(cond)
        {
            System.out.println("loda");
        }
        else
        {
            System.out.println("Loda");
        }










    }
}