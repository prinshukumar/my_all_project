
#include<iostream>

using namespace std;

int main()
{
	// prints hello world
	cout<<"Hello World";
	
	return 0;
}
