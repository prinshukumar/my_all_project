a=int(input())
b=int(input())
c=int(input())
if a > b:
    print('a is >')
else:
    print('b is greater')   


if a > b & a < c:
    print('a is >')
else:
    print('b is greater')      