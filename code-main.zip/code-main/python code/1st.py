print('hello')
c='idhu'
import flask
print(3+4 ,end=" ")
 

num = input ("Enter number :")   #input come with string
print(num,end=" ")
a= input("enter the value:")
print(a)
#thes a+num is string
print(a+num)
#to print input tipe casting is nessacery
print(int(a) +1)


print(3+5 ,end=" ")
print(a , num ,end=" ")
print(a + num ,end=" ")
print(a + c)

print(a + 'hello')



s="54"
q="11"
z=1
print(s+q)
print( int(s+q))
print(int(s) + int(q))
print(str(z) + q)

# .........  error show......
#   print(str(z) + q)

#only for string
print(10 * "hello \n")

print(10 * z )

