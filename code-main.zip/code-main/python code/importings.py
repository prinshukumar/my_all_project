import rec

print(rec.facteriolss(6))