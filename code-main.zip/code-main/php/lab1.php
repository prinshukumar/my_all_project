<?php

$name=" ishu<br>";
echo "hello " ;
echo "$name <br>";

#$x=8 . $y=9;
$x=8 ; $y=9;

$c=$x+$y;

echo $c."<br>";

var_dump($x);


$fr=array("a","b","c");

echo $fr[0] ."<br>" . $fr[1] ."<br>";

$a=5;
if($a > 2)
{
    echo "hello";
}
 ?>