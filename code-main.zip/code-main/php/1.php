<html>
    <head>
    <title>      <?php echo "hello"; ?>    </title>

    </head>

<body>

<p>hh</p>

<?php

Echo "My first PHP script!<br>";
$a=5;
echo"<br>$a <br>";
?>
 <!-- $a=7;   // thiss line is excutead-->
<?php
echO "My first PHP script!<br>";
echo"<br>$a <br>";

?>

<?php
eCho "My first PHP script!<br>";
echo"<br>$a <br>";
?>

<?php
ECHO "My first PHP script!<br>";
?>

</body>
</html>