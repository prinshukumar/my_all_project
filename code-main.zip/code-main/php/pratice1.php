<?php

$name= "ishu";
echo $name;
# echo "hi";       eg show for new line

echo "<pre>             hello            </pre>";    //pre new line ma la raha  hha br ke need nahe ha
echo " <pre>";
echo rtrim("            hel           ");
ecHo ltrim("            heo           ");
Echo " </pre>";

echo str_repeat($name ."<br>",5);
/////////////////////////////////////////////////////////////////////////////////////////
echo "/////////////////////////////////////////////////////////////////////////////////////////";

       echo "<br><pre>                               for next practice in video" ;



$a=5;
$b=7;
echo "<br> add   " . ($a + $b) . "<br>";
echo "<br> **   " . ($a ** $b) . "<br>";
echo " %   " . ($a % $b) . "<br><br>";

echo var_dump( $a >= 2);
echo $a >= 2;

echo "==   " . ($a==$b) ."<br>";
echo ">   " . ($a<$b)    ."<br>";
echo "<   " . ($a>$b)."<br>";
echo "< >  " . ($a<>$b)."<br>";

$a=true;
$b=false;

echo "==   " . ($a==$b) ."<br>";

echo var_dump($a and $b);
echo var_dump($a or $b);
echo var_dump($a && $b);
echo var_dump($a || $b);

echO "<br>!  cheak  ->   " . !$b ;
/////////////////////////////////////////////////////////////////////////////////////////////
echo "/////////////////////////////////////////////////////////////////////////////////////////////";











?>