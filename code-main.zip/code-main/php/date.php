<?php
// these are  use less
// echo $date("datetime");
//echo "<br>";
$a=date("Date");
echo $a."<br>" ;
$b=date(" D jS F Y , g:i a");
echo $b;



?>