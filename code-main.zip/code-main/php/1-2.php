 gghvggggggggg
 $a=9;    <!--     code run at it is -->
<?php
$a=8;
echo "<br>$a<br>";
?>
<?php
echo "$a<br>";
?>
<?php
echo "$a<br>";
?>
<?php
echo "$a<br>";
?>
<?php
echo "$a<br>";
?>
<!-- hello njndbcccccccccccccccccc -->
<?php
echo "<br>";
$b=9;
echo $b;
printre();
?>

<?php
function printre()
{
    global $b;
    $b=10;
    echo "<br>";
    echo $b;
}
?>
<?php
echo "<br>";
echo $b;
?>

