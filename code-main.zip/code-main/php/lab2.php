<?php
echo (abs(7)."<br>");
echo (abs(-7)."<br>");
echo (abs(ceil(-(3.7)))."<br>");
echo (abs(floor(-(3.7)))."<br>");
echo (ceil(-(6.5))."<br>");
echo (ceil(6.5)."<br>");
echo (floor(5.5)."<br>");
echo (floor(-(5.5))."<br>");
//echo (floor(-(5.5))."<br");

echo (dechex(5)."<br>");
echo (decbin(6)."<br>");


?>