# Mini-Project-on-ML
Movie recommendation , Trade mill analysis  ,And Web scripting
