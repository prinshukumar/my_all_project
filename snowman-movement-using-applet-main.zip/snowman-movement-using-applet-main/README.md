# snow-man-using-applet
we have to create a snowman using applet 
