class Boolens {

    public static void main(String args[])
    {

        boolean b=true;
        System.out.println(b);
        b=false;
        System.out.println(b);

        if(b==true)
        {
            System.out.println("excuiteaded");
        }
        else{
            System.out.println("not excuitead");
        }

        System.out.println("cheak  "+ (10<9));

    }
    
}
