package workshop;

public class Character_ascii {

    public static void main(String[] args)

    {
        char ch1,ch2;
        ch1=88;
        System.out.println(ch1);
        ch2=++ch1;
        System.out.println(ch2);
    }
    
}
