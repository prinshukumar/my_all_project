package workshop;

public class Long_and_Int {
    public static void main(String[] arg)
    {
        int lightspeed;
        long lightspeed1;
        int day=100566;
        long day1=100566;
        int time;
        long time1;
        int distance;
        long distance1;
        lightspeed = 24*day*60*60;
        lightspeed1 = 24*day1*60*60;

        System.out.println(lightspeed);
        System.out.println(lightspeed1);


    }
    
}
