class Arrays
{
    public static void main(String args[])
    {
        int ishu[]={1,2,3,4,5,6,7,8,9,1};
        System.out.println(ishu[4]);
    }
}