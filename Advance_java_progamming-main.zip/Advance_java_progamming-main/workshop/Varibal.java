package workshop;

public class Varibal {
    public static void main(String[] args)
    {
        int num =100;
        System.out.println(num);
        num=2*num;
        System.out.println(num);

    }
    
}
