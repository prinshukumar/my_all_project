# compiler_programm
#Here my compiler programmer , which is written in c-language.
#some basic programming like arthmatics operations ,pattern maching by grammer , count no of character 
