# Brick-Breaker-Game-In-Java
The Brick Breaker Game In Java It is made up of bricks that are aligned at the top of the screen. The player is represented by a little ball that sits on a small platform at the bottom of the screen. The arrow buttons on the computer can be used to move the platform on the screen from left to right. The player uses the platform to keep the ball moving forward. 
