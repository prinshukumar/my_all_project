echo "enter the inputs"

read person

echo "name  is $person"

