read a
while [ $a -gt 5 ]
do
echo $a

let a++

done
