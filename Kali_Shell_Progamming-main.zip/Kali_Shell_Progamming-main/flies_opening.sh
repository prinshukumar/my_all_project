name="home/ishu/ex"

# give the paths of the files

for names in $(cat $name)
do
echo $names
done
