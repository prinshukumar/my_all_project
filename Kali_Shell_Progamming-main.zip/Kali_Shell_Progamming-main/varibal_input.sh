echo "Press any key for making the varibals"

read a
name=ishu
hi=$name

echo $hi
echo $a

a=$hi

echo $a

host=$(hostname)
l=$(user)

echo $host and $l
