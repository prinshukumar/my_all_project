echo "enter the no"

read a

case $a in
1)hi;;

2)lode;;

*)echo o on;;
esac
