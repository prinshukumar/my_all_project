for num in 1 2 task
do 
echo $num
done

for num in {1..100}
do
echo hi
done


