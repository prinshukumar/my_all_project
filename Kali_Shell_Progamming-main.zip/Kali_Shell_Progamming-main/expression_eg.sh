echo "add the number"

$y =~ ' expr 6+7 '

echo "$y"

