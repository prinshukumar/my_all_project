# Kali_Shell_Progamming
Basics of kail shell scripting programs , and that is  important programs for beginner .
