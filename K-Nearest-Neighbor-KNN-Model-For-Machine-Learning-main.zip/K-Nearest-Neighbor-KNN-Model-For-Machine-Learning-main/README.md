# K-Nearest-Neighbor-KNN-Model-For-Machine-Learning
IN this model we have to pridect the customer will by item or not
