# NumPy-Pandas-and-Matplotlib-basics-tutorial
tutorial of some basic numpy ,pandas and matplotlib library in python , which is used full for Machine Learning 
