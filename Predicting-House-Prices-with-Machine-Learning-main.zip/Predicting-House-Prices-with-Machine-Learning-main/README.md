# Predicting-House-Prices-with-Machine-Learning
Linear Regression is the algorithm that is used for predicting House prices among various other algorithms. on the giving the input of SQRT it predict the Price


https://predicting-house-price-with-ml.herokuapp.com/
