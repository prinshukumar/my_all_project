# Login-APK
As an Android developer, building an APK It allows you to create a distributable file that can be installed on Android devices for testing, sharing, or publishing on app stores. in this apk we have to submit the user id and password then it will send to the next page of the application
