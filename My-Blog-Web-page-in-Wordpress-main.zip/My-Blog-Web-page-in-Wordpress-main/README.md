# Blog-Web-page-in-Wordpress
To open the Blog Web Page , I have to strongleey recommendet to you have a XAMMP app in whic you have a DataBase name wordprss and it must be open and this file(wordpress) is located in htdos file 


you have to open xammp and open the MYSQL server and Appachi both shiuld be open other wise they Blog page will not work properly
