# Identifying-Digits-Images-using-Logistic-Regression-in-ML
In this model  on giving image (8*8) size of the digits it will predict the which images is given by user
