# Principal-Component-Analysis-in-ML
Principal Component Analysis in ML(pree processing work)
