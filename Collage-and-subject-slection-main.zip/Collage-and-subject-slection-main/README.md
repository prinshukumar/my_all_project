# Collage-and-subject-slection
In this APK we have to slected the collage and subject and result are shown below the page
